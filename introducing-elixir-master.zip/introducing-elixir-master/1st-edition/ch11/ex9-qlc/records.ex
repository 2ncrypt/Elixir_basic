defrecord Planemo, name: :nil, gravity: 0, diameter: 0, distance_from_sun: 0
defrecord Tower, location: "", height: 20, planemo: :earth, name: ""
