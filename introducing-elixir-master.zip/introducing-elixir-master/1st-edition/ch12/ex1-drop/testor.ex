defmodule Testor do
   def __struct__ do
	   %{}
	end
end

