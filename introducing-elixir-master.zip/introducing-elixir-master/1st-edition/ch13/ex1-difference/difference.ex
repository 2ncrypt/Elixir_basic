defmodule Difference do

  defmacro m_test(x) do
    IO.puts("#{inspect(x)}")
    x
  end
  
  def f_test(x) do
    IO.puts("#{inspect(x)}")
    x
  end

end
