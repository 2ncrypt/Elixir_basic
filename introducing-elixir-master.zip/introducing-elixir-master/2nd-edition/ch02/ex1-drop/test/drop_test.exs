defmodule DropTest do
  use ExUnit.Case
  doctest Drop

  test "the truth" do
    assert 1 + 1 == 2
  end
end
