defmodule CombinedTest do
  use ExUnit.Case
  doctest Combined

  test "the truth" do
    assert 1 + 1 == 2
  end
end
