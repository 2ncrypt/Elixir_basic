# Combined

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed as:

  1. Add `combined` to your list of dependencies in `mix.exs`:

    ```elixir
    def deps do
      [{:combined, "~> 0.1.0"}]
    end
    ```

  2. Ensure `combined` is started before your application:

    ```elixir
    def application do
      [applications: [:combined]]
    end
    ```

