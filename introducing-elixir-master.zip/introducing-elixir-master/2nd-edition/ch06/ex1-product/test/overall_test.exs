defmodule OverallTest do
  use ExUnit.Case
  doctest Overall

  test "the truth" do
    assert 1 + 1 == 2
  end
end
