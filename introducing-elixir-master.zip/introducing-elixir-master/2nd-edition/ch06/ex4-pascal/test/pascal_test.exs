defmodule PascalTest do
  use ExUnit.Case
  doctest Pascal

  test "the truth" do
    assert 1 + 1 == 2
  end
end
