defmodule ListDrop do
end
