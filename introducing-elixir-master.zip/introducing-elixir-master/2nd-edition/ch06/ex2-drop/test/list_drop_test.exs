defmodule ListDropTest do
  use ExUnit.Case
  doctest ListDrop

  test "the truth" do
    assert 1 + 1 == 2
  end
end
