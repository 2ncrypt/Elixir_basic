defmodule MathDemo do
end
