defmodule StructDropTest do
  use ExUnit.Case
  doctest StructDrop

  test "the truth" do
    assert 1 + 1 == 2
  end
end
