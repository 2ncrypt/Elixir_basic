defmodule ValidTest do
  use ExUnit.Case
  doctest Valid

  test "the truth" do
    assert 1 + 1 == 2
  end
end
