# Tower

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed as:

  1. Add `tower` to your list of dependencies in `mix.exs`:

    ```elixir
    def deps do
      [{:tower, "~> 0.1.0"}]
    end
    ```

  2. Ensure `tower` is started before your application:

    ```elixir
    def application do
      [applications: [:tower]]
    end
    ```

