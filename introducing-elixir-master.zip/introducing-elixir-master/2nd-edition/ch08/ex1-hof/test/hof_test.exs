defmodule HofTest do
  use ExUnit.Case
  doctest Hof

  test "the truth" do
    assert 1 + 1 == 2
  end
end
