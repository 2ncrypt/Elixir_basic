# MphDrop

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed as:

  1. Add `mph_drop` to your list of dependencies in `mix.exs`:

    ```elixir
    def deps do
      [{:mph_drop, "~> 0.1.0"}]
    end
    ```

  2. Ensure `mph_drop` is started before your application:

    ```elixir
    def application do
      [applications: [:mph_drop]]
    end
    ```

