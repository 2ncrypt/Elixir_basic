# Bounce

**TODO: Add description**

## Installation

If [available in Hex](https://hex.pm/docs/publish), the package can be installed as:

  1. Add `bounce` to your list of dependencies in `mix.exs`:

    ```elixir
    def deps do
      [{:bounce, "~> 0.1.0"}]
    end
    ```

  2. Ensure `bounce` is started before your application:

    ```elixir
    def application do
      [applications: [:bounce]]
    end
    ```

