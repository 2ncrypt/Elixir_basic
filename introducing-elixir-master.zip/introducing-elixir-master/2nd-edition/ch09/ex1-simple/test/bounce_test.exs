defmodule BounceTest do
  use ExUnit.Case
  doctest Bounce

  test "the truth" do
    assert 1 + 1 == 2
  end
end
